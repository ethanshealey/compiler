# Compiler
By Ethan Shealey

# HOW TO RUN
make all

./compiler <prog_name>

# CLEAN UP .o FILES
make clean
